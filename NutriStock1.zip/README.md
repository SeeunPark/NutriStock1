# News Stack

Node package 설치
```
npm install
```

서버 실행
```
supervisor app.js
```
